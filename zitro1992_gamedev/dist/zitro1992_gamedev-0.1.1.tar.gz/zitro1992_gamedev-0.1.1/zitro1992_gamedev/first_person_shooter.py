class FirstPersonShooter():
    def __init__(self, name: str) -> None:
        self.name=name

    def hello_world():
        return "This is hello world from my first project!"